<?php
   include "classes/Conexao.php";
   //Pega o id enviado pelo header
   session_start();
   $id = $_SESSION['id'];
   $sql = "SELECT * FROM tb_professores WHERE
            usuario_id = '{$id}'";
   $resultado = $conexao->query($sql);
   $linha = $resultado->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Aluno</title>
    <style> 
            *{margin:0;padding:0;box-sizing: border-box;}
        html{font-size:10px;font-family:Verdana, Geneva, Tahoma, sans-serif}
        header{width:100vw;height: 8em;background-color: black;display:flex;}
        body{display: flex;flex-direction: column;width: 100vw;height: 100vh;}

        .logo{display: flex;flex-direction: column;background-color: black;color:white;width: fit-content;}
.logo h1{font-size:5em;text-align: end;}
.logo h2{text-align: end;margin-top:-10px;font-size:1rem;}
.logo h3{text-align:end;font-size:1rem;}

.sefi{width: 100%;}
.sefi h1{color: #b20000;font-size:7em;margin-left:55%;translate: -38%;}     
    .modal {
	background-color: rgba(0, 0, 0, 0.8);
	width: 100vw;
	height: 100vh;
    margin:0;
	position: absolute;

	top: 0;
	display: none;
	justify-content: center;
	align-items: center;
    
}
.close {margin-left: 275px;
    margin-top: -10px;
	position:fixed;
    z-index:20;
    width: fit-content;
    height: fit-content;
    
	font-size: 42px;
	color: #333;
	transform: rotate(45deg);
	cursor: pointer;
	&:hover {
		color: #666;
	}
}
.conteudo{width: 300px;height: 100px;display: flex;flex-direction: column;background-color: white;}
.conteudo label{font-size:20px;text-align: center;}
.conteudo select{font-size: 17px;width: fit-content;margin:auto;margin-top: 10px}
.conteudo button{width: fit-content;height: 2em;margin:auto;font-size:14px;border-radius: 10px;}
select{border-radius: 20px;padding:20px,0,20px,0;}
nav{background-color:#600000;width: 100vw;height:8em;display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr ; grid-template-areas: 'novoestagio novodocumento perfil pendenteassinado analisadoassinado';}
.pendenteassinado{grid-area:perfil;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.analisadoassinado{grid-area:perfil;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.perfil{grid-area:perfil;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.novoestagio{grid-area:novoestagio;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.novodocumento{grid-area:novodocumento;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.perfil:hover, .novoestagio:hover, .novodocumento:hover , .acompanhamento:hover, .pendenteassinado:hover, .analisadoassinado:hover{background-color:red;}



.perfil p{color:white;font-weight:700;font-size:2em;cursor:pointer; }
.novoestagio p{color:white;font-weight:700;font-size:2em;cursor:pointer;    }
.novodocumento p{color:white;font-weight:700;font-size:2em;cursor:pointer;  }
.analisadoassinado p{color:white;font-weight:700;font-size:2em;cursor:pointer;  }
.pendenteassinado p{color:white;font-weight:700;font-size:2em;cursor:pointer;  }
a{text-decoration:none;}

.corpo{width: 100%;height:100%;background-color:rgb(220,220,220);display:flex;flex-direction:column;align-items:center;}
    .inicial{grid-area:inicial;text-align:center;}
    .instrucoes{grid-area:instrucoes;}
    .imagem{grid-area:imagem;}

    .botao{grid-area:botao;display:flex;justify-content:center;}

    .corpo h1{margin:20px 0 20px 0;font-size:4em}
.instrucoes h4{margin:20px 0 20px 0;font-size:1.5em;
padding:5px;}
.circle{width: 8rem;height:8rem;border-radius:100%;background-color:white;display:flex;justify-content:center;align-items:center;font-size:1.9em;color:black;font-weight:600;}
header a{text-decoration:none;}
.acompanhamento{grid-area:acompanhamento;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.acompanhamento p{color:white;font-weight:700;font-size:2em;cursor:pointer;  }
.documento{width: 80%;padding:5px;display:flex;align-items:center;}
.documento p{font-size:2em;margin:10px;}
    </style>
</head> 
<body style="overflow:hidden;">
<header>
        <div class="logo">
            <h1>Fatec</h1>
            <h2>Itapira</h2>
            <h3>Ogari de Castro Pacheco</h3>
        </div>
        <div class="sefi"><h1>SEFI</h1></div>
        <a href="views/usuarios/usuario-logout.php"><div class="circle">Sair</div></a>
    </header>
<nav>  
     <a href="professor.php">
        <div class="perfil">
            <p>Perfil</p>
        </div>
    </a>
    <a href="professorpendente.php">
        <div class="novoestagio">
            <p>Documentos pendentes</p>
        </div>
    </a>
    <a href="professoravaliados.php">
        <div class="novodocumento">
            <p>Documentos avaliados</p>
       </div>
    </a>  
    <a href="pendenteassinado.php">
        <div class="pendenteassinado">
            <p>Assinados pendentes</p>
        </div>

    </a>
    <a href="analisadoassinado.php">
        <div class="analisadoassinado">
            <p>Assinados avaliados</p>
        </div>
    </a>
    <!-- <a href="alunoacompanhar.php">
        <div class="acompanhamento">
            <p>Acompanhar processos</p>
        </div></a> -->
   
</nav>
<div class="corpo" style="overflow:auto;">
    <h2>Bem vindo <?=$linha['nome']?></h2>
    <p>Veja abaixo documentos pendentes para você analisar!</p>
    <?php if (!isset($_POST['filtro'])){
   echo '         <form action="professoravaliados.php" method="post">';
   echo '         <label for="filtro">Filtrar por:</label>';
   echo '         <select name="filtro" id="filtro">';
   echo '         <option value="null" selected>Selecione uma opção</option>';
   echo '         <option value="termocompromisso.pdf">Termo de compromisso</option>';
   echo '         <option value="relatoriofinal.pdf">Relatório final</option>';
   echo '         <option value="relatorioparcial.pdf">Relatório parcial</option>';
   echo '         <option value="termorescisão.pdf">Termo de rescisão</option>';
   echo '         <option value="sem">Retirar filtro</option>';
   echo ' </select>   ';
   echo ' <label for="nomefiltro">Filtrar por nome:</label>';
   echo ' <input type="text" name="nomefiltro" id="nomefiltro">';
   echo ' <input type="submit" value="Filtrar">';
   echo '     </form>';
}
elseif ($_POST['filtro'] == 'null'){
    echo '         <form action="professoravaliados.php" method="post">';
    echo '         <label for="filtro">Filtrar por:</label>';
    echo '         <select name="filtro" id="filtro">';
    echo '         <option value="null" selected>Selecione uma opção</option>';
    echo '         <option value="termocompromisso.pdf">Termo de compromisso</option>';
    echo '         <option value="relatoriofinal.pdf">Relatório final</option>';
    echo '         <option value="relatorioparcial.pdf">Relatório parcial</option>';
    echo '         <option value="termorescisão.pdf">Termo de rescisão</option>';
    echo '         <option value="sem">Retirar filtro</option>';
    echo ' </select>   ';
    echo ' <label for="nomefiltro">Filtrar por nome:</label>';
    echo ' <input type="text" name="nomefiltro" id="nomefiltro">';
    echo ' <input type="submit" value="Filtrar">';
    echo '     </form>';
}    
elseif ($_POST['filtro'] == 'termocompromisso.pdf'){
    echo '         <form action="professoravaliados.php" method="post">';
    echo '         <label for="filtro">Filtrar por:</label>';
    echo '         <select name="filtro" id="filtro">';
    echo '         <option value="null" >Selecione uma opção</option>';
    echo '         <option value="termocompromisso.pdf" selected>Termo de compromisso</option>';
    echo '         <option value="relatoriofinal.pdf">Relatório final</option>';
    echo '         <option value="relatorioparcial.pdf">Relatório parcial</option>';
    echo '         <option value="termorescisão.pdf">Termo de rescisão</option>';
    echo '         <option value="sem">Retirar filtro</option>';
    echo ' </select>   ';
    echo ' <label for="nomefiltro">Filtrar por nome:</label>';
    echo ' <input type="text" name="nomefiltro" id="nomefiltro">';
    echo ' <input type="submit" value="Filtrar">';
    echo '     </form>';
}    elseif ($_POST['filtro'] == 'relatoriofinal.pdf'){
    echo '         <form action="professoravaliados.php" method="post">';
    echo '         <label for="filtro">Filtrar por:</label>';
    echo '         <select name="filtro" id="filtro">';
    echo '         <option value="null" >Selecione uma opção</option>';
    echo '         <option value="termocompromisso.pdf">Termo de compromisso</option>';
    echo '         <option value="relatoriofinal.pdf" selected >Relatório final</option>';
    echo '         <option value="relatorioparcial.pdf">Relatório parcial</option>';
    echo '         <option value="termorescisão.pdf">Termo de rescisão</option>';
    echo '         <option value="sem">Retirar filtro</option>';
    echo ' </select>   ';
    echo ' <label for="nomefiltro">Filtrar por nome:</label>';
    echo ' <input type="text" name="nomefiltro" id="nomefiltro">';
    echo ' <input type="submit" value="Filtrar">';
    echo '     </form>';
}    elseif ($_POST['filtro'] == 'relatorioparcial.pdf'){
    echo '         <form action="professoravaliados.php" method="post">';
    echo '         <label for="filtro">Filtrar por:</label>';
    echo '         <select name="filtro" id="filtro">';
    echo '         <option value="null" >Selecione uma opção</option>';
    echo '         <option value="termocompromisso.pdf">Termo de compromisso</option>';
    echo '         <option value="relatoriofinal.pdf">Relatório final</option>';
    echo '         <option value="relatorioparcial.pdf" selected>Relatório parcial</option>';
    echo '         <option value="termorescisão.pdf">Termo de rescisão</option>';
    echo '         <option value="sem">Retirar filtro</option>';
    echo ' </select>   ';
    echo ' <label for="nomefiltro">Filtrar por nome:</label>';
    echo ' <input type="text" name="nomefiltro" id="nomefiltro">';
    echo ' <input type="submit" value="Filtrar">';
    echo '     </form>';
}    elseif ($_POST['filtro'] == 'termorescisão.pdf'){
    echo '         <form action="professoravaliados.php" method="post">';
    echo '         <label for="filtro">Filtrar por:</label>';
    echo '         <select name="filtro" id="filtro">';
    echo '         <option value="null">Selecione uma opção</option>';
    echo '         <option value="termocompromisso.pdf">Termo de compromisso</option>';
    echo '         <option value="relatoriofinal.pdf">Relatório final</option>';
    echo '         <option value="relatorioparcial.pdf">Relatório parcial</option>';
    echo '         <option value="termorescisão.pdf" selected>Termo de rescisão</option>';
    echo '         <option value="sem">Retirar filtro</option>';
    echo ' </select>   ';
    echo ' <label for="nomefiltro">Filtrar por nome:</label>';
    echo ' <input type="text" name="nomefiltro" id="nomefiltro">';
    echo ' <input type="submit" value="Filtrar">';
    echo '     </form>';
}    elseif ($_POST['filtro'] == 'sem'){
    echo '         <form action="professoravaliados.php" method="post">';
    echo '         <label for="filtro">Filtrar por:</label>';
    echo '         <select name="filtro" id="filtro">';
    echo '         <option value="null" >Selecione uma opção</option>';
    echo '         <option value="termocompromisso.pdf">Termo de compromisso</option>';
    echo '         <option value="relatoriofinal.pdf">Relatório final</option>';
    echo '         <option value="relatorioparcial.pdf">Relatório parcial</option>';
    echo '         <option value="termorescisão.pdf">Termo de rescisão</option>';
    echo '         <option value="sem" selected>Retirar filtro</option>';
    echo ' </select>   ';
    echo ' <label for="nomefiltro">Filtrar por nome:</label>';
    echo ' <input type="text" name="nomefiltro" id="nomefiltro">';
    echo ' <input type="submit" value="Filtrar">';
    echo '     </form>';
}    



    ?>
    <!-- <form action="professoravaliados.php" method="post">
        <label for="filtro">Filtrar por:</label>
        <select name="filtro" id="filtro">
        <option value="null" selected>Selecione uma opção</option>
        <option value="termocompromisso.pdf">Termo de compromisso</option>
        <option value="relatoriofinal.pdf">Relatório final</option>
        <option value="relatorioparcial.pdf">Relatório parcial</option>
        <option value="termorescisão.pdf">Termo de rescisão</option>
        <option value="sem">Retirar filtro</option>
</select>   
<label for="nomefiltro">Filtrar por nome:</label>
<input type="text" name="nomefiltro" id="nomefiltro">
<input type="submit" value="Filtrar">
    </form> -->

    <?php 
    if (isset($_POST['nomefiltro']) && $_POST['nomefiltro']!= ''){
        $novosql = "SELECT id FROM tb_alunos WHERE nome = '".$_POST['nomefiltro']."';";
        $resultado = $conexao->query($novosql);
        $resultado1 = $resultado->fetch();
        $idaluno = $resultado1['id'];
        if ($_POST['filtro'] == 'termocompromisso.pdf'){
            $sql = "SELECT * FROM `tb_documentos` WHERE aluno_id = $idaluno and nome = 'termocompromisso.pdf' and status != 'pendente' ";
         
         }elseif ($_POST['filtro'] == 'relatoriofinal.pdf'){
            $sql = "SELECT * FROM `tb_documentos` WHERE aluno_id = $idaluno and nome = 'relatoriofinal.pdf' and status != 'pendente'";
         }
         elseif ($_POST['filtro'] == 'relatorioparcial.pdf'){
            $sql = "SELECT * FROM `tb_documentos` WHERE aluno_id = $idaluno and nome = 'relatorioparcial.pdf' and status != 'pendente'";
         }
         elseif ($_POST['filtro'] == 'termorescisão.pdf'){
            $sql = "SELECT * FROM `tb_documentos` WHERE aluno_id = $idaluno and nome = 'termorescisão.pdf' and status != 'pendente'";
         }
         elseif ($_POST['filtro'] == 'null' || $_POST['filtro'] == 'sem' ){
             $sql = "SELECT * FROM tb_documentos WHERE status != 'pendente' and aluno_id = $idaluno;";
         }
    }elseif (isset($_POST['filtro'])){ if ($_POST['filtro'] == 'termocompromisso.pdf'){
        $sql = "SELECT * FROM `tb_documentos` WHERE nome = 'termocompromisso.pdf' and status != 'pendente' ";
     
     }elseif ($_POST['filtro'] == 'relatoriofinal.pdf'){
        $sql = "SELECT * FROM `tb_documentos` WHERE nome = 'relatoriofinal.pdf' and status != 'pendente'";
     }
     elseif ($_POST['filtro'] == 'relatorioparcial.pdf'){
        $sql = "SELECT * FROM `tb_documentos` WHERE nome = 'relatorioparcial.pdf' and status != 'pendente'";
     }
     elseif ($_POST['filtro'] == 'termorescisão.pdf'){
        $sql = "SELECT * FROM `tb_documentos` WHERE nome = 'termorescisão.pdf' and status != 'pendente'";
     }
     elseif ($_POST['filtro'] == 'null' || $_POST['filtro'] == 'sem' ){
         $sql = "SELECT * FROM tb_documentos WHERE status != 'pendente';";}
        
     }else{$sql = "SELECT * FROM tb_documentos WHERE status != 'pendente';";}
    $resultado = $conexao->query($sql);
    $lista = $resultado->fetchAll();
    
    foreach ($lista as $linha){
        
        $alunoid = $linha['aluno_id'];
        $sql1 = "SELECT nome FROM tb_alunos WHERE usuario_id = $alunoid";
        $resultado = $conexao->query($sql1);
        $resultado1 = $resultado->fetch();
        $nomealuno = $resultado1['nome'];
        
    ?>
    <div class="documento">
        <p><?php echo $nomealuno; ?></p>
        <p><?php echo $linha['nome']; ?></p>
        
        <form action="mostrarpdf.php" method="post" target="_blank">
            <input type="hidden" name="id_documento" value="<?php echo $linha['id']?>">
            <input type="submit" value="documento">
        </form>
        <p><?php echo $linha['status']?> </p>
    </div>
 <?php }?>
</div>

    <!--
     <h1>Pagina Professor</h1>
       <p>
 //if($id == null){
  //  echo"Sem id de professor";
//}else{
// echo $id;
 //echo "<h3>Nome: ".$linha['nome']."</h3>";
 //echo "<h3>Email: ".$linha['email']."</h3>";
//}

</p>

<a href="views/usuarios/usuario-logout.php"><button> logout </button></a>



 //  if ($stmt->rowCount() > 0) {
       // echo "<h2>Lista de Alunos</h2>";
    //     echo "<table border='1'>";
    //     echo "
    //     <tr>
    //     <th>Nome</th>
    //     <th>RA</th>
    //     <th>Curso</th>
    //     <th>Documentos</th>
    //     </tr>";

    //     // Itera sobre os resultados da consulta e exibe cada aluno em uma linha da tabela
    //     while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    //         $id = $row['id'];
    //         echo "<tr>";
    //         echo "<td>".$row['nome']."</td>";
    //         echo "<td>".$row['ra']."</td>";
    //         echo "<td>".$row['curso']."</td>";
    //         echo "<td><a href='documentos_visualizar.php?id=$id'>Documentos</a></td>";

    //         echo "</tr>";
    //     }

    //     echo "</table>";
    // } else {
     //   echo "<p>Nenhum aluno encontrado.</p>";
   // }




 -->

</body>
</html>






