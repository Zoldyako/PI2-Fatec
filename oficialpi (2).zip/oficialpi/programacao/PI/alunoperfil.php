<?php
   include "classes/Conexao.php";
   session_start();
   //Pega o id enviado pelo header
   $id = $_SESSION['id'];
   $sql = "SELECT * FROM tb_alunos WHERE
            usuario_id = '{$id}'";
   $resultado = $conexao->query($sql);
   $linha = $resultado->fetch();
   
   
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Aluno</title>
    <style> 
            *{margin:0;padding:0;box-sizing: border-box;}
        html{font-size:10px;font-family:Verdana, Geneva, Tahoma, sans-serif}
        header{width:100vw;height: 8em;background-color: black;display:flex;}
        body{display: flex;flex-direction: column;width: 100vw;height: 100vh;}

        .logo{display: flex;flex-direction: column;background-color: black;color:white;width: fit-content;}
.logo h1{font-size:5em;text-align: end;}
.logo h2{text-align: end;margin-top:-10px;font-size:1rem;}
.logo h3{text-align:end;font-size:1rem;}

.sefi{width: 100%;}
.sefi h1{color: #b20000;font-size:7em;margin-left:55%;translate: -38%;}     
    .modal {
	background-color: rgba(0, 0, 0, 0.8);
	width: 100vw;
	height: 100vh;
    margin:0;
	position: absolute;

	top: 0;
	display: none;
	justify-content: center;
	align-items: center;
    
}
.close {margin-left: 275px;
    margin-top: -10px;
	position:fixed;
    z-index:20;
    width: fit-content;
    height: fit-content;
    
	font-size: 42px;
	color: #333;
	transform: rotate(45deg);
	cursor: pointer;
	&:hover {
		color: #666;
	}
}
.conteudo{width: 300px;height: 100px;display: flex;flex-direction: column;background-color: white;}
.conteudo label{font-size:20px;text-align: center;}
.conteudo select{font-size: 17px;width: fit-content;margin:auto;margin-top: 10px}
.conteudo button{width: fit-content;height: 2em;margin:auto;font-size:14px;border-radius: 10px;}
select{border-radius: 20px;padding:20px,0,20px,0;}
nav{background-color:#600000;width: 100vw;height:8em;display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr; grid-template-areas: 'novoestagio novodocumento perfil acompanhamento assinado';}
.assinado{grid-area:assinado;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.assinado p{color:white;font-weight:700;font-size:2em;cursor:pointer; }
.perfil{grid-area:perfil;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.novoestagio{grid-area:novoestagio;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.novodocumento{grid-area:novodocumento;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.perfil:hover, .novoestagio:hover, .novodocumento:hover, .acompanhamento:hover, .assinado:hover{background-color:red;}



.perfil p{color:white;font-weight:700;font-size:2em;cursor:pointer; }
.novoestagio p{color:white;font-weight:700;font-size:2em;cursor:pointer;    }
.novodocumento p{color:white;font-weight:700;font-size:2em;cursor:pointer;  }
a{text-decoration:none;}

.corpo{width: 100%;height:100%;background-color:rgb(220,220,220);text-align:center;}
.corpo h1{margin:20px 0 20px 0;font-size:4em}
.corpo h3{margin:20px 0 20px 0;font-size:3em}
.circle{width: 8rem;height:8rem;border-radius:100%;background-color:white;display:flex;justify-content:center;align-items:center;font-size:1.9em;color:black;font-weight:600;}
header a{text-decoration:none;}

.acompanhamento{grid-area:acompanhamento;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.acompanhamento p{color:white;font-weight:700;font-size:2em;cursor:pointer;  }
    </style>
</head>
<body>
<header>
        <div class="logo">
            <h1>Fatec</h1>
            <h2>Itapira</h2>
            <h3>Ogari de Castro Pacheco</h3>
        </div>
        <div class="sefi"><h1>SEFI</h1></div>
        <a href="views/usuarios/usuario-logout.php"><div class="circle">Sair</div></a>
    </header>
<nav>
    <a href="novoestagio.php" >
        <div class="novoestagio">
            <p>Solicitar novo estágio</p>
        </div>
    </a>
    
    <a href="novodocumento.php" >
        <div class="novodocumento">
            <p>Gerar novo documento</p>
       </div>
    </a> 

    <a href="alunoperfil.php">
        <div class="perfil">
            <p>Perfil</p>
        </div>
    </a>
    <a href="alunoacompanhar.php">
        <div class="acompanhamento">
            <p>Acompanhar processos</p>
        </div>
    </a>
    <a href="alunoassinado.php">
        <div class="assinado">
            <p>Documentos assinados</p>
        </div>
    </a>
</nav>
    <div class="corpo">
    <h2>Bem vindo <?=$linha['nome']?></h2>
    <p>Veja abaixo dados sobre seu usuário tais como nome,R.A., disciplina... caso alguma anormalidade favor consultar a secretaria!</p>
  <h1>Perfil</h1> 
    <p><?php

 echo "<h3>Nome: ".$linha['nome']."</h3>";
 echo "<h3>Disciplina: ".$linha['curso']."</h3>";
 echo "<h3>RA: ".$linha['ra']."</h3>";

?></p>


</div>


<!--
<a href="views/usuarios/usuario-logout.php"><button> logout </button></a>
<br>
<h2>Upload de Documento</h2>
    <form action="upload.php" method="POST" enctype="multipart/form-data">
        Selecione um arquivo PDF:
        <input type="file" name="documento" accept="application/pdf" required>
        <br><br>
        <input type="submit" value="Enviar Documento">
    </form>
    <button id="mostrar">Novo documento</button>
    <div class="modal">
<div class="conteudo" >
    <div class="close">+</div>

    <label for="estagio111" >Selecione tipo do documento</label>
    <select name="estagio111" id="estagio111">
        <option value="" selected>Selecione uma opção</option>
        <option value="OR">Obrigatório Remunerado</option>
        <option value="ONR">Obrigatório Não Remunerado</option>
        <option value="RP">Relatório Parcial</option>
        <option value="RF">Relatório Final</option>
        <option value="TR">Termo de rescisão</option>
    </select>
    <button onclick="obterValorSelect()"> Exibir formulário</button>
   </div> 
</div>
    <script>
        document.getElementById("mostrar").addEventListener("click",function(){document.querySelector('.modal').style.display = "flex";})

        document.querySelector('.close').addEventListener("click", function() {
	document.querySelector('.modal').style.display = "none";
});


        function obterValorSelect()
        {
            var select=document.getElementById("estagio111").value
            if (select=="ONR"){
                window.location.href = "formONR.html"
                
                
            } else if (select == "OR"){
                window.location.href = "formOR.html"
            }
            else if (select == "RP"){
                window.location.href = "formRP.html"
            }
            else if (select == "RF"){
                window.location.href = "formRF.html"
            }
            else if(select == "TR"){
                window.location.href = "formTR.html"
            }
            
            
            
            else{
                alert("Selecione uma opção válida")
            }
            
        }
    </script> -->

</body>
</html>