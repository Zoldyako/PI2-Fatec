<?php
   include "classes/Conexao.php";
   session_start();
   //Pega o id enviado pelo header
   $id = $_SESSION['id'];
   $sql = "SELECT * FROM tb_alunos WHERE
            usuario_id = '{$id}'";
   $resultado = $conexao->query($sql);
   $linha = $resultado->fetch();
   
   
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Aluno</title>
    <style> 
            *{margin:0;padding:0;box-sizing: border-box;}
        html{font-size:10px;font-family:Verdana, Geneva, Tahoma, sans-serif}
        header{width:100vw;height: 8em;background-color: black;display:flex;}
        body{display: flex;flex-direction: column;width: 100vw;height: 100vh;}

        .logo{display: flex;flex-direction: column;background-color: black;color:white;width: fit-content;}
.logo h1{font-size:5em;text-align: end;}
.logo h2{text-align: end;margin-top:-10px;font-size:1rem;}
.logo h3{text-align:end;font-size:1rem;}

.sefi{width: 100%;}
.sefi h1{color: #b20000;font-size:7em;margin-left:55%;translate: -38%;}     
    .modal {
	background-color: rgba(0, 0, 0, 0.8);
	width: 100vw;
	height: 100vh;
    margin:0;
	position: absolute;

	top: 0;
	display: none;
	justify-content: center;
	align-items: center;
    
}
.close {margin-left: 275px;
    margin-top: -10px;
	position:fixed;
    z-index:20;
    width: fit-content;
    height: fit-content;
    
	font-size: 42px;
	color: #333;
	transform: rotate(45deg);
	cursor: pointer;
	&:hover {
		color: #666;
	}
}
.conteudo{width: 300px;height: 100px;display: flex;flex-direction: column;background-color: white;}
.conteudo label{font-size:20px;text-align: center;}
.conteudo select{font-size: 17px;width: fit-content;margin:auto;margin-top: 10px}
.conteudo button{width: fit-content;height: 2em;margin:auto;font-size:14px;border-radius: 10px;}
select{border-radius: 20px;padding:20px,0,20px,0;}
nav{background-color:#600000;width: 100vw;height:8em;display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr; grid-template-areas: 'novoestagio novodocumento perfil acompanhamento assinado';}
.assinado{grid-area:assinado;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.assinado p{color:white;font-weight:700;font-size:2em;cursor:pointer; }
.perfil{grid-area:perfil;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.novoestagio{grid-area:novoestagio;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.novodocumento{grid-area:novodocumento;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.perfil:hover, .novoestagio:hover, .novodocumento:hover, .acompanhamento:hover , .assinado:hover{background-color:red;}



.perfil p{color:white;font-weight:700;font-size:2em;cursor:pointer; }
.novoestagio p{color:white;font-weight:700;font-size:2em;cursor:pointer;    }
.novodocumento p{color:white;font-weight:700;font-size:2em;cursor:pointer;  }
a{text-decoration:none;}

.corpo{width: 100%;height:100%;background-color:rgb(220,220,220);text-align:center;overflow-x:hidden;overflow-y:scroll;}
.corpo h1{margin:20px 0 20px 0;font-size:4em}
.corpo h3{margin:20px 0 20px 0;font-size:3em}
.circle{width: 8rem;height:8rem;border-radius:100%;background-color:white;display:flex;justify-content:center;align-items:center;font-size:1.9em;color:black;font-weight:600;}
header a{text-decoration:none;}

.acompanhamento{grid-area:acompanhamento;display:flex;justify-content:center;align-items:center;width:100%;height:100%;}
.acompanhamento p{color:white;font-weight:700;font-size:2em;cursor:pointer;  }
.item{width: 80%; min-height:100px;border:2px solid black;margin:30px;display:flex;align-items:center;justify-content:space-around;font-size:2rem}

.centralizar{width: 100%;height:90%;display:flex;align-items:center;flex-direction:column;}
    </style>
</head>
<body style="overflow:hidden">
<header>
        <div class="logo">
            <h1>Fatec</h1>
            <h2>Itapira</h2>
            <h3>Ogari de Castro Pacheco</h3>
        </div>
        <div class="sefi"><h1>SEFI</h1></div>
        <a href="views/usuarios/usuario-logout.php"><div class="circle">Sair</div></a>
    </header>
<nav>
    <a href="novoestagio.php" >
        <div class="novoestagio">
            <p>Solicitar novo estágio</p>
        </div>
    </a>
    
    <a href="novodocumento.php" >
        <div class="novodocumento">
            <p>Gerar novo documento</p>
       </div>
    </a> 

    <a href="alunoperfil.php">
        <div class="perfil">
            <p>Perfil</p>
        </div>
    </a>
    <a href="alunoacompanhar.php">
        <div class="acompanhamento">
            <p>Acompanhar processos</p>
        </div>
    </a>
    <a href="alunoassinado.php">
        <div class="assinado">
            <p>Documentos assinados</p>
        </div>
    </a>

</nav>
<div class="corpo">
    <h2>Bem vindo <?=$linha['nome']?></h2>
    <p>acompanhe abaixo avaliações sobre seus documentos enviados para o professor</p>
    
    <form action="alunoacompanhar.php" method="post">
        <label for="filtro">Filtrar por:</label>
        <select name="filtro" id="filtro">
        <option value="null" selected>Selecione uma opção</option>
        <option value="termocompromisso.pdf">Termo de compromisso</option>
        <option value="relatoriofinal.pdf">Relatório final</option>
        <option value="relatorioparcial.pdf">Relatório parcial</option>
        <option value="termorescisão.pdf">Termo de rescisão</option>
        <option value="sem">Retirar filtro</option>
</select>   
<input type="submit" value="Filtrar">
    </form>

    <div class="centralizar">
         <?php 
            if (isset($_POST['filtro'])){
                if ($_POST['filtro'] == 'termocompromisso.pdf'){
                   $sql = "SELECT * FROM `tb_documentos` WHERE aluno_id = $id ORDER BY CASE WHEN nome = 'termocompromisso.pdf' THEN 0 ELSE 1 END, nome;";
                }elseif ($_POST['filtro'] == 'relatoriofinal.pdf'){
                    $sql = "SELECT * FROM `tb_documentos` WHERE aluno_id = $id ORDER BY CASE WHEN nome = 'relatoriofinal.pdf' THEN 0 ELSE 1 END, nome;";
                }elseif ($_POST['filtro'] == 'relatorioparcial.pdf'){
                    $sql = "SELECT * FROM `tb_documentos` WHERE aluno_id = $id ORDER BY CASE WHEN nome = 'relatorioparcial.pdf' THEN 0 ELSE 1 END, nome;";
                }elseif ($_POST['filtro'] == 'termorescisão.pdf'){
                    $sql = "SELECT * FROM `tb_documentos` WHERE aluno_id = $id ORDER BY CASE WHEN nome = 'termorescisão.pdf' THEN 0 ELSE 1 END, nome;";
                }elseif ($_POST['filtro'] == 'null' || $_POST['filtro'] == 'sem' ){
                    $sql = "SELECT * FROM tb_documentos WHERE aluno_id = $id;";
                }
            }
            else{ $sql = "SELECT * FROM tb_documentos WHERE aluno_id = $id;";}
           
            $resultado = $conexao->query($sql);
            $lista = $resultado->fetchAll();
            foreach ($lista as $linha){
            ?>

      <div class="item">
           
        
       <h4>Nome do arquivo: <?php echo $linha['nome']?></h4>   
    <div style='width:fit-content'><a href='documentos_visualizar_processo.php?id=<?php echo $linha["id"]?>' target='_blank'><button style="font-size:2rem;padding:4px;cursor:pointer;">Baixar documento</button></a></div>
       <h4>Status: <?php echo $linha['status']?>    </h4>
        
       <form action="" method="post">
                <input type="hidden" name="<?php echo $linha['id'];?>" value="<?php echo $linha['comentario']?>" id="<?php echo $linha['id'];?>">
                <?php if ($linha['comentario']!=NULL){?>
                <input type="submit" value="Comentário" onclick="exibir(<?php echo $linha['id'];?>)">
                <?php }?>
       </form>
       </div>
       

<?php } ?>        
    </div>
</div>
<script>
    function exibir(id){
        let comentario = document.getElementById(String(id)).value;
        if (comentario == ''){alert('Sem comentários disponível')}
        else{
        alert(comentario);
        }
    }

</script>
</body>
</html>