<?php
    

        #Celular
        //$conexao = new PDO('mysql:host=127.0.0.1;dbname=sis_estagio', 'root', '');

 
        #Notbook
        $conexao = new PDO('mysql:host=localhost;dbname=sis-estagio', 'root', '');
    

    

?>