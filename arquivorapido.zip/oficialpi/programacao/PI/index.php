<?php

include("classes/Conexao.php");
include("views/usuarios/usuario-verifica.php");

if(isset($_GET['erro'])){
  $erro = $_GET['erro'];  
} else{
  $erro = null;
}


?>



<!DOCTYPE html>
<html lang="pt-br">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>

        *{margin:0;padding:0;box-sizing: border-box;}
        html{font-size:10px;font-family:Verdana, Geneva, Tahoma, sans-serif}
        header{width:100vw;height: 8em;background-color: black;display:flex;}
        body{display: flex;flex-direction: column;width: 100vw;height: 100vh;}
        .corpo{width: 100%;height: 100%;display: flex;flex-direction: column;justify-content: center;align-items: center;translate:0 -15%;}
        .logo{display: flex;flex-direction: column;background-color: black;color:white;width: fit-content;}
.logo h1{font-size:5em;text-align: end;}
.logo h2{text-align: end;margin-top:-10px;font-size:1rem;}
.logo h3{text-align:end;font-size:1rem;}

.sefi{width: 100%;}
.sefi h1{color: #b20000;font-size:7em;margin-left:55%;translate: -38%;}
main h1{color: #b20000;font-size:2.5em;}
main{
    display: flex;justify-content: center;align-items: center;flex-direction: column;
}
main label{font-size:1.8em;}
main input{margin:7px;font-size:1.5em;background-color:rgb(230,230,230);border-radius:2px;padding:2px;border:2px solid}
main input[type=submit]{font-size:2em;width: 130px;border-radius:5px;color:white;background-color:black;cursor:pointer;}
main form{display:flex;justify-content:center;flex-direction:column;align-items:center;}

    </style>
    <title>Sistema estágio</title>

</head>

<body>

<header>
        <div class="logo">
            <h1>Fatec</h1>
            <h2>Itapira</h2>
            <h3>Ogari de Castro Pacheco</h3>
        </div>
        <div class="sefi"><h1>SEFI</h1></div>
    </header>

    <div class="corpo">
    <main>
    <h1 style="margin:-10px 0 10px 0;">Sistema de Estágio Fatec Itapira</h1>
        <form action="views/usuarios/usuario-login.php" method="POST">
            

            <div>
                <label for="usuario">Login: </label>
                <input type="text" name="usuario" id="usuario" placeholder="Digite seu usuario" required style="margin-left:15px;">
            </div>

            <div>
                <label for="usuario">Senha: </label>
                <input type="password" name="senha" placeholder="Digite sua senha" required>
            </div>
            <span style="color:red;"><?php echo $erro; ?></span>

            <div>
                <input type="submit" value="Entrar">
            </div>

        </form>
        </main>
</div>
</body>

</html>